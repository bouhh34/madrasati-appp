MA MADRASSA ANDROID APP

This package is designed to be added to the root of your GitHub repository.

Upload:
1) the folder android-app
2) the folder .github

GitHub Actions will build an Android APK automatically.

APK output:
Actions > Build Android APK > latest successful run > Artifacts > Ma-Madrassa-APK

The app opens:
https://madrasati-appp-real.onrender.com/

Security choices included:
- HTTPS only
- cleartext HTTP disabled
- no file/content access
- mixed content blocked
- third-party cookies disabled
- SSL errors are NOT bypassed
